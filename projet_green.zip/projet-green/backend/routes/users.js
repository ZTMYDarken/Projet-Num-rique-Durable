const express = require('express');
const router = express.Router();
const pool = require('../db/mysql');
const isAuthenticated = require('../middleware/auth');
const hasRole = require('../middleware/roles');
const bcrypt = require('bcrypt');

router.get('/', isAuthenticated, async (req, res) => {
  try {
    const [rows] = await pool.query(
      'SELECT id, nom, prenom, email, role, class_id, created_at FROM users ORDER BY id DESC LIMIT 20'
    );
    res.json(rows);
  } catch (error) {
    console.error('Erreur GET users :', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

router.post('/', isAuthenticated, hasRole('admin', 'enseignant'), async (req, res) => {
  try {
    const { nom, prenom, email, role, password, class_id } = req.body;

    if (!nom || !prenom || !email || !role || !password) {
      return res.status(400).json({ error: 'Champs obligatoires manquants.' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    await pool.query(
      'INSERT INTO users (nom, prenom, email, role, password_hash, class_id) VALUES (?, ?, ?, ?, ?, ?)',
      [nom, prenom, email, role, hashedPassword, class_id || null]
    );

    res.status(201).json({ message: 'Utilisateur créé.' });
  } catch (error) {
    console.error('Erreur POST users :', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

module.exports = router;
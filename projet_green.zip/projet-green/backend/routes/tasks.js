const express = require('express');
const router = express.Router();
const pool = require('../db/mysql');
const isAuthenticated = require('../middleware/auth');

router.get('/', isAuthenticated, async (req, res) => {
  try {
    const { group_id } = req.query;

    let query = `
      SELECT id, titre, description, statut, date_limite, group_id, created_by, created_at
      FROM tasks
    `;
    const params = [];

    if (group_id) {
      query += ' WHERE group_id = ?';
      params.push(group_id);
    }

    query += ' ORDER BY id DESC';

    const [rows] = await pool.query(query, params);
    res.json(rows);
  } catch (error) {
    console.error('Erreur GET tasks :', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

router.post('/', isAuthenticated, async (req, res) => {
  try {
    const { titre, description, statut, date_limite, group_id, created_by } = req.body;

    if (!titre || !group_id || !created_by) {
      return res.status(400).json({ error: 'Titre, group_id et created_by obligatoires.' });
    }

    await pool.query(
      'INSERT INTO tasks (titre, description, statut, date_limite, group_id, created_by) VALUES (?, ?, ?, ?, ?, ?)',
      [titre, description || null, statut || 'a_faire', date_limite || null, group_id, created_by]
    );

    res.status(201).json({ message: 'Tâche créée.' });
  } catch (error) {
    console.error('Erreur POST tasks :', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

module.exports = router;
const express = require('express');
const router = express.Router();
const pool = require('../db/mysql');
const isAuthenticated = require('../middleware/auth');
const hasRole = require('../middleware/roles');

router.get('/', isAuthenticated, async (req, res) => {
  try {
    const { project_id } = req.query;

    let query = `
      SELECT id, nom, project_id, created_at
      FROM project_groups
    `;
    const params = [];

    if (project_id) {
      query += ' WHERE project_id = ?';
      params.push(project_id);
    }

    query += ' ORDER BY id DESC';

    const [rows] = await pool.query(query, params);
    res.json(rows);
  } catch (error) {
    console.error('Erreur GET groups :', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

router.post('/', isAuthenticated, hasRole('enseignant', 'admin'), async (req, res) => {
  try {
    const { nom, project_id } = req.body;

    if (!nom || !project_id) {
      return res.status(400).json({ error: 'Nom et project_id obligatoires.' });
    }

    await pool.query(
      'INSERT INTO project_groups (nom, project_id) VALUES (?, ?)',
      [nom, project_id]
    );

    res.status(201).json({ message: 'Groupe de projet créé.' });
  } catch (error) {
    console.error('Erreur POST groups :', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

router.post('/members', isAuthenticated, hasRole('enseignant', 'admin'), async (req, res) => {
  try {
    const { group_id, user_id } = req.body;

    if (!group_id || !user_id) {
      return res.status(400).json({ error: 'group_id et user_id obligatoires.' });
    }

    await pool.query(
      'INSERT INTO group_members (group_id, user_id) VALUES (?, ?)',
      [group_id, user_id]
    );

    res.status(201).json({ message: 'Élève ajouté au groupe.' });
  } catch (error) {
    console.error('Erreur POST groups/members :', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

module.exports = router;
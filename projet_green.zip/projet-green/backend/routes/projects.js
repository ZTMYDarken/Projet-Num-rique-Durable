const express = require('express');
const router = express.Router();
const pool = require('../db/mysql');
const isAuthenticated = require('../middleware/auth');
const hasRole = require('../middleware/roles');

router.get('/', isAuthenticated, async (req, res) => {
  try {
    const { class_id } = req.query;
    const user = req.session.user;

    let query = `
      SELECT id, titre, description, class_id, teacher_id, created_at
      FROM projects
    `;
    const params = [];
    const where = [];

    if (class_id) {
      where.push('class_id = ?');
      params.push(class_id);
    }

    if (user.role === 'enseignant') {
      where.push('teacher_id = ?');
      params.push(user.id);
    }

    if (user.role === 'eleve' && user.class_id) {
      where.push('class_id = ?');
      params.push(user.class_id);
    }

    if (where.length > 0) {
      query += ' WHERE ' + where.join(' AND ');
    }

    query += ' ORDER BY id DESC';

    const [rows] = await pool.query(query, params);
    res.json(rows);
  } catch (error) {
    console.error('Erreur GET projects :', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

router.post('/', isAuthenticated, hasRole('enseignant', 'admin'), async (req, res) => {
  try {
    const { titre, description, class_id, teacher_id } = req.body;

    if (!titre || !class_id || !teacher_id) {
      return res.status(400).json({ error: 'Titre, class_id et teacher_id obligatoires.' });
    }

    await pool.query(
      'INSERT INTO projects (titre, description, class_id, teacher_id) VALUES (?, ?, ?, ?)',
      [titre, description || null, class_id, teacher_id]
    );

    res.status(201).json({ message: 'Projet créé.' });
  } catch (error) {
    console.error('Erreur POST projects :', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

module.exports = router;
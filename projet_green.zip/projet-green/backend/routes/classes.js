const express = require('express');
const router = express.Router();
const pool = require('../db/mysql');
const isAuthenticated = require('../middleware/auth');
const hasRole = require('../middleware/roles');

router.get('/', isAuthenticated, async (req, res) => {
  try {
    const user = req.session.user;
    let query = '';
    let params = [];

    if (user.role === 'admin') {
      query = 'SELECT id, nom, teacher_id, created_at FROM classes ORDER BY id DESC';
    } else if (user.role === 'enseignant') {
      query = 'SELECT id, nom, teacher_id, created_at FROM classes WHERE teacher_id = ? ORDER BY id DESC';
      params = [user.id];
    } else {
      query = 'SELECT id, nom, teacher_id, created_at FROM classes WHERE id = ? ORDER BY id DESC';
      params = [user.class_id];
    }

    const [rows] = await pool.query(query, params);
    res.json(rows);
  } catch (error) {
    console.error('Erreur GET classes :', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

router.post('/', isAuthenticated, hasRole('enseignant', 'admin'), async (req, res) => {
  try {
    const { nom, teacher_id } = req.body;

    if (!nom || !teacher_id) {
      return res.status(400).json({ error: 'Nom et teacher_id obligatoires.' });
    }

    await pool.query(
      'INSERT INTO classes (nom, teacher_id) VALUES (?, ?)',
      [nom, teacher_id]
    );

    res.status(201).json({ message: 'Classe créée.' });
  } catch (error) {
    console.error('Erreur POST classes :', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

module.exports = router;
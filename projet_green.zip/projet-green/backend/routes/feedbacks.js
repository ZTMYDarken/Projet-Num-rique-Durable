const express = require('express');
const router = express.Router();
const pool = require('../db/mysql');
const isAuthenticated = require('../middleware/auth');
const hasRole = require('../middleware/roles');

router.get('/', isAuthenticated, async (req, res) => {
  try {
    const { group_id } = req.query;

    let query = `
      SELECT id, contenu, teacher_id, group_id, task_id, created_at
      FROM feedbacks
    `;
    const params = [];

    if (group_id) {
      query += ' WHERE group_id = ?';
      params.push(group_id);
    }

    query += ' ORDER BY id DESC';

    const [rows] = await pool.query(query, params);
    res.json(rows);
  } catch (error) {
    console.error('Erreur GET feedbacks :', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

router.post('/', isAuthenticated, hasRole('enseignant', 'admin'), async (req, res) => {
  try {
    const { contenu, teacher_id, group_id, task_id } = req.body;

    if (!contenu || !teacher_id || !group_id) {
      return res.status(400).json({ error: 'Contenu, teacher_id et group_id obligatoires.' });
    }

    await pool.query(
      'INSERT INTO feedbacks (contenu, teacher_id, group_id, task_id) VALUES (?, ?, ?, ?)',
      [contenu, teacher_id, group_id, task_id || null]
    );

    res.status(201).json({ message: 'Feedback ajouté.' });
  } catch (error) {
    console.error('Erreur POST feedbacks :', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

module.exports = router;
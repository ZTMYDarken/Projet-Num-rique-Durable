const express = require('express');
const router = express.Router();
const pool = require('../db/mysql');
const bcrypt = require('bcrypt');

router.get('/test-db', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT 1 AS test');
    res.json({ message: 'Connexion MySQL OK', rows });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erreur base de données.' });
  }
});

router.post('/register', async (req, res) => {
  try {
    const { nom, prenom, email, password, role, class_id } = req.body;

    if (!nom || !prenom || !email || !password || !role) {
      return res.status(400).json({ error: 'Tous les champs obligatoires doivent être remplis.' });
    }

    const [existingUser] = await pool.query(
      'SELECT id FROM users WHERE email = ?',
      [email]
    );

    if (existingUser.length > 0) {
      return res.status(400).json({ error: 'Cet email existe déjà.' });
    }

    const password_hash = await bcrypt.hash(password, 10);

    await pool.query(
      'INSERT INTO users (nom, prenom, email, password_hash, role, class_id) VALUES (?, ?, ?, ?, ?, ?)',
      [nom, prenom, email, password_hash, role, class_id || null]
    );

    res.status(201).json({ message: 'Inscription réussie.' });
  } catch (error) {
    console.error('Erreur register :', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    const [rows] = await pool.query(
      'SELECT id, nom, prenom, email, password_hash, role, class_id FROM users WHERE email = ?',
      [email]
    );

    if (rows.length === 0) {
      return res.status(400).json({ error: 'Utilisateur introuvable.' });
    }

    const user = rows[0];
    const isMatch = await bcrypt.compare(password, user.password_hash);

    if (!isMatch) {
      return res.status(400).json({ error: 'Mot de passe incorrect.' });
    }

    req.session.user = {
      id: user.id,
      nom: user.nom,
      prenom: user.prenom,
      email: user.email,
      role: user.role,
      class_id: user.class_id
    };

    res.json({ message: 'Connexion réussie.', user: req.session.user });
  } catch (error) {
    console.error('Erreur login :', error);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

router.get('/me', (req, res) => {
  if (!req.session.user) {
    return res.status(401).json({ error: 'Non connecté.' });
  }

  res.json(req.session.user);
});

router.post('/logout', (req, res) => {
  req.session.destroy((error) => {
    if (error) {
      return res.status(500).json({ error: 'Erreur lors de la déconnexion.' });
    }

    res.json({ message: 'Déconnexion réussie.' });
  });
});

module.exports = router;
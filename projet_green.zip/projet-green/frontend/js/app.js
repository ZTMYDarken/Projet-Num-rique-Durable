console.log('app.js chargé');

// -------------------- INSCRIPTION --------------------
const registerForm = document.getElementById('registerForm');

if (registerForm) {
  console.log('registerForm trouvé');

  registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    console.log('submit inscription intercepté');

    const messageEl = document.getElementById('message');

    const data = {
      nom: document.getElementById('nom')?.value.trim(),
      prenom: document.getElementById('prenom')?.value.trim(),
      email: document.getElementById('email')?.value.trim(),
      password: document.getElementById('password')?.value,
      role: document.getElementById('role')?.value
    };

    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });

      const result = await response.json();
      if (messageEl) {
        messageEl.textContent = result.message || result.error || 'Réponse inconnue.';
      }

      console.log('Résultat inscription :', result);

      if (result.message) {
        registerForm.reset();
      }
    } catch (error) {
      console.error('Erreur inscription :', error);
      if (messageEl) {
        messageEl.textContent = 'Erreur de connexion au serveur.';
      }
    }
  });
}

// -------------------- CONNEXION --------------------
const loginForm = document.getElementById('loginForm');

if (loginForm) {
  console.log('loginForm trouvé');

  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    console.log('submit connexion intercepté');

    const loginMessage = document.getElementById('loginMessage');

    const data = {
      email: document.getElementById('loginEmail')?.value.trim(),
      password: document.getElementById('loginPassword')?.value
    };

    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });

      const result = await response.json();
      if (loginMessage) {
        loginMessage.textContent = result.message || result.error || 'Réponse inconnue.';
      }

      console.log('Résultat connexion :', result);

      if (result.message) {
        window.location.href = '/dashboard.html';
      }
    } catch (error) {
      console.error('Erreur connexion :', error);
      if (loginMessage) {
        loginMessage.textContent = 'Erreur de connexion au serveur.';
      }
    }
  });
}

// -------------------- DECONNEXION --------------------
const logoutBtn = document.getElementById('logoutBtn');

if (logoutBtn) {
  logoutBtn.addEventListener('click', async () => {
    const logoutMessage = document.getElementById('logoutMessage');

    try {
      const response = await fetch('/api/auth/logout', {
        method: 'POST'
      });

      const result = await response.json();

      if (logoutMessage) {
        logoutMessage.textContent = result.message || result.error || '';
      }

      if (result.message) {
        window.location.href = '/login.html';
      }
    } catch (error) {
      console.error('Erreur déconnexion :', error);
      if (logoutMessage) {
        logoutMessage.textContent = 'Erreur serveur.';
      }
    }
  });
}

// -------------------- AFFICHAGE USERS --------------------
const usersList = document.getElementById('usersList');

if (usersList) {
  fetch('/api/users')
    .then(response => response.json())
    .then(data => {
      usersList.innerHTML = '';

      if (!Array.isArray(data)) {
        usersList.innerHTML = '<li>Erreur de chargement.</li>';
        return;
      }

      data.forEach(user => {
        const li = document.createElement('li');
        li.textContent = `${user.prenom} ${user.nom} - ${user.email} - ${user.role}`;
        usersList.appendChild(li);
      });
    })
    .catch(error => {
      console.error('Erreur affichage users :', error);
      usersList.innerHTML = '<li>Erreur serveur.</li>';
    });
}

// -------------------- CREATION USER --------------------
const createUserForm = document.getElementById('createUserForm');

if (createUserForm) {
  createUserForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const userMessage = document.getElementById('userMessage');

    const data = {
      nom: document.getElementById('userNom')?.value.trim(),
      prenom: document.getElementById('userPrenom')?.value.trim(),
      email: document.getElementById('userEmail')?.value.trim(),
      role: document.getElementById('userRole')?.value,
      password_hash: document.getElementById('userPassword')?.value
    };

    try {
      const response = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });

      const result = await response.json();

      if (userMessage) {
        userMessage.textContent = result.message || result.error || '';
      }

      if (result.message) {
        createUserForm.reset();
        setTimeout(() => location.reload(), 500);
      }
    } catch (error) {
      console.error('Erreur création user :', error);
      if (userMessage) {
        userMessage.textContent = 'Erreur serveur.';
      }
    }
  });
}

// -------------------- MODIFICATION USER --------------------
const editUserForm = document.getElementById('editUserForm');

if (editUserForm) {
  editUserForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const editUserMessage = document.getElementById('editUserMessage');
    const id = document.getElementById('editUserId')?.value;

    const data = {
      nom: document.getElementById('editUserNom')?.value.trim(),
      prenom: document.getElementById('editUserPrenom')?.value.trim(),
      email: document.getElementById('editUserEmail')?.value.trim(),
      role: document.getElementById('editUserRole')?.value
    };

    try {
      const response = await fetch(`/api/users/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });

      const result = await response.json();

      if (editUserMessage) {
        editUserMessage.textContent = result.message || result.error || '';
      }

      if (result.message) {
        editUserForm.reset();
        setTimeout(() => location.reload(), 500);
      }
    } catch (error) {
      console.error('Erreur modification user :', error);
      if (editUserMessage) {
        editUserMessage.textContent = 'Erreur serveur.';
      }
    }
  });
}

// -------------------- SUPPRESSION USER --------------------
const deleteUserForm = document.getElementById('deleteUserForm');

if (deleteUserForm) {
  deleteUserForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const deleteUserMessage = document.getElementById('deleteUserMessage');
    const id = document.getElementById('deleteUserId')?.value;
    const confirmed = window.confirm('Confirmer la suppression de cet utilisateur ?');

    if (!confirmed) return;

    try {
      const response = await fetch(`/api/users/${id}`, {
        method: 'DELETE'
      });

      const result = await response.json();

      if (deleteUserMessage) {
        deleteUserMessage.textContent = result.message || result.error || '';
      }

      if (result.message) {
        deleteUserForm.reset();
        setTimeout(() => location.reload(), 500);
      }
    } catch (error) {
      console.error('Erreur suppression user :', error);
      if (deleteUserMessage) {
        deleteUserMessage.textContent = 'Erreur serveur.';
      }
    }
  });
}

// -------------------- AFFICHAGE PROJECTS --------------------
const projectsList = document.getElementById('projectsList');

if (projectsList) {
  fetch('/api/projects')
    .then(response => response.json())
    .then(data => {
      projectsList.innerHTML = '';

      if (!Array.isArray(data)) {
        projectsList.innerHTML = '<li>Erreur de chargement.</li>';
        return;
      }

      data.forEach(project => {
        const li = document.createElement('li');
        li.textContent = `${project.titre} - professeur ID : ${project.teacher_id}`;
        projectsList.appendChild(li);
      });
    })
    .catch(error => {
      console.error('Erreur affichage projects :', error);
      projectsList.innerHTML = '<li>Erreur serveur.</li>';
    });
}

// -------------------- CREATION PROJECT --------------------
const createProjectForm = document.getElementById('createProjectForm');

if (createProjectForm) {
  createProjectForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const projectMessage = document.getElementById('projectMessage');

    const data = {
      titre: document.getElementById('projectTitre')?.value.trim(),
      description: document.getElementById('projectDescription')?.value.trim(),
      teacher_id: document.getElementById('projectTeacherId')?.value
    };

    try {
      const response = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });

      const result = await response.json();

      if (projectMessage) {
        projectMessage.textContent = result.message || result.error || '';
      }

      if (result.message) {
        createProjectForm.reset();
        setTimeout(() => location.reload(), 500);
      }
    } catch (error) {
      console.error('Erreur création projet :', error);
      if (projectMessage) {
        projectMessage.textContent = 'Erreur serveur.';
      }
    }
  });
}

// -------------------- MODIFICATION PROJECT --------------------
const editProjectForm = document.getElementById('editProjectForm');

if (editProjectForm) {
  editProjectForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const editProjectMessage = document.getElementById('editProjectMessage');
    const id = document.getElementById('editProjectId')?.value;

    const data = {
      titre: document.getElementById('editProjectTitre')?.value.trim(),
      description: document.getElementById('editProjectDescription')?.value.trim()
    };

    try {
      const response = await fetch(`/api/projects/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });

      const result = await response.json();

      if (editProjectMessage) {
        editProjectMessage.textContent = result.message || result.error || '';
      }

      if (result.message) {
        editProjectForm.reset();
        setTimeout(() => location.reload(), 500);
      }
    } catch (error) {
      console.error('Erreur modification projet :', error);
      if (editProjectMessage) {
        editProjectMessage.textContent = 'Erreur serveur.';
      }
    }
  });
}

// -------------------- SUPPRESSION PROJECT --------------------
const deleteProjectForm = document.getElementById('deleteProjectForm');

if (deleteProjectForm) {
  deleteProjectForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const deleteProjectMessage = document.getElementById('deleteProjectMessage');
    const id = document.getElementById('deleteProjectId')?.value;
    const confirmed = window.confirm('Confirmer la suppression de ce projet ?');

    if (!confirmed) return;

    try {
      const response = await fetch(`/api/projects/${id}`, {
        method: 'DELETE'
      });

      const result = await response.json();

      if (deleteProjectMessage) {
        deleteProjectMessage.textContent = result.message || result.error || '';
      }

      if (result.message) {
        deleteProjectForm.reset();
        setTimeout(() => location.reload(), 500);
      }
    } catch (error) {
      console.error('Erreur suppression projet :', error);
      if (deleteProjectMessage) {
        deleteProjectMessage.textContent = 'Erreur serveur.';
      }
    }
  });
}

// -------------------- AFFICHAGE TASKS --------------------
const tasksList = document.getElementById('tasksList');

if (tasksList) {
  fetch('/api/tasks')
    .then(response => response.json())
    .then(data => {
      tasksList.innerHTML = '';

      if (!Array.isArray(data)) {
        tasksList.innerHTML = '<li>Erreur de chargement.</li>';
        return;
      }

      data.forEach(task => {
        const li = document.createElement('li');
        li.textContent = `${task.titre} - ${task.statut} - projet ${task.project_id} - créé par ${task.created_by}`;
        tasksList.appendChild(li);
      });
    })
    .catch(error => {
      console.error('Erreur affichage tasks :', error);
      tasksList.innerHTML = '<li>Erreur serveur.</li>';
    });
}

// -------------------- CREATION TASK --------------------
const createTaskForm = document.getElementById('createTaskForm');

if (createTaskForm) {
  createTaskForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const taskMessage = document.getElementById('taskMessage');

    const data = {
      titre: document.getElementById('taskTitre')?.value.trim(),
      description: document.getElementById('taskDescription')?.value.trim(),
      statut: document.getElementById('taskStatut')?.value,
      date_limite: document.getElementById('taskDateLimite')?.value || null,
      project_id: document.getElementById('taskProjectId')?.value,
      created_by: document.getElementById('taskCreatedBy')?.value
    };

    try {
      const response = await fetch('/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });

      const result = await response.json();

      if (taskMessage) {
        taskMessage.textContent = result.message || result.error || '';
      }

      if (result.message) {
        createTaskForm.reset();
        setTimeout(() => location.reload(), 500);
      }
    } catch (error) {
      console.error('Erreur création tâche :', error);
      if (taskMessage) {
        taskMessage.textContent = 'Erreur serveur.';
      }
    }
  });
}

// -------------------- MODIFICATION TASK --------------------
const editTaskForm = document.getElementById('editTaskForm');

if (editTaskForm) {
  editTaskForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const editTaskMessage = document.getElementById('editTaskMessage');
    const id = document.getElementById('editTaskId')?.value;

    const data = {
      titre: document.getElementById('editTaskTitre')?.value.trim(),
      description: document.getElementById('editTaskDescription')?.value.trim(),
      statut: document.getElementById('editTaskStatut')?.value,
      date_limite: document.getElementById('editTaskDateLimite')?.value || null
    };

    try {
      const response = await fetch(`/api/tasks/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });

      const result = await response.json();

      if (editTaskMessage) {
        editTaskMessage.textContent = result.message || result.error || '';
      }

      if (result.message) {
        editTaskForm.reset();
        setTimeout(() => location.reload(), 500);
      }
    } catch (error) {
      console.error('Erreur modification tâche :', error);
      if (editTaskMessage) {
        editTaskMessage.textContent = 'Erreur serveur.';
      }
    }
  });
}

// -------------------- SUPPRESSION TASK --------------------
const deleteTaskForm = document.getElementById('deleteTaskForm');

if (deleteTaskForm) {
  deleteTaskForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const deleteTaskMessage = document.getElementById('deleteTaskMessage');
    const id = document.getElementById('deleteTaskId')?.value;
    const confirmed = window.confirm('Confirmer la suppression de cette tâche ?');

    if (!confirmed) return;

    try {
      const response = await fetch(`/api/tasks/${id}`, {
        method: 'DELETE'
      });

      const result = await response.json();

      if (deleteTaskMessage) {
        deleteTaskMessage.textContent = result.message || result.error || '';
      }

      if (result.message) {
        deleteTaskForm.reset();
        setTimeout(() => location.reload(), 500);
      }
    } catch (error) {
      console.error('Erreur suppression tâche :', error);
      if (deleteTaskMessage) {
        deleteTaskMessage.textContent = 'Erreur serveur.';
      }
    }
  });
}

// -------------------- AFFICHAGE FEEDBACKS --------------------
const feedbacksList = document.getElementById('feedbacksList');

if (feedbacksList) {
  fetch('/api/feedbacks')
    .then(response => response.json())
    .then(data => {
      feedbacksList.innerHTML = '';

      if (!Array.isArray(data)) {
        feedbacksList.innerHTML = '<li>Erreur de chargement.</li>';
        return;
      }

      data.forEach(feedback => {
        const li = document.createElement('li');
        li.textContent = `${feedback.contenu} - prof ${feedback.teacher_id} - projet ${feedback.project_id}${feedback.task_id ? ` - tâche ${feedback.task_id}` : ''}`;
        feedbacksList.appendChild(li);
      });
    })
    .catch(error => {
      console.error('Erreur affichage feedbacks :', error);
      feedbacksList.innerHTML = '<li>Erreur serveur.</li>';
    });
}

// -------------------- CREATION FEEDBACK --------------------
const createFeedbackForm = document.getElementById('createFeedbackForm');

if (createFeedbackForm) {
  createFeedbackForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const feedbackMessage = document.getElementById('feedbackMessage');
    const taskValue = document.getElementById('feedbackTaskId')?.value;

    const data = {
      contenu: document.getElementById('feedbackContenu')?.value.trim(),
      teacher_id: document.getElementById('feedbackTeacherId')?.value,
      project_id: document.getElementById('feedbackProjectId')?.value,
      task_id: taskValue ? taskValue : null
    };

    try {
      const response = await fetch('/api/feedbacks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });

      const result = await response.json();

      if (feedbackMessage) {
        feedbackMessage.textContent = result.message || result.error || '';
      }

      if (result.message) {
        createFeedbackForm.reset();
        setTimeout(() => location.reload(), 500);
      }
    } catch (error) {
      console.error('Erreur création feedback :', error);
      if (feedbackMessage) {
        feedbackMessage.textContent = 'Erreur serveur.';
      }
    }
  });
}